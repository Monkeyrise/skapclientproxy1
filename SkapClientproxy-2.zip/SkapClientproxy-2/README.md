# SkapClient

[SkapClient](https://nky5223.github.io/SkapClient) is an unofficial client for [skap](https://skap.io).

If you fork SkapClient, please credit me :]

To premiering: no leaking scripts >:(